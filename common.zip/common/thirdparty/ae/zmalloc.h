#ifndef _ZMALLOC_H
#define _ZMALLOC_H

#ifndef zmalloc
#define zmalloc malloc
#endif

#ifndef zfree
#define zfree free
#endif

#ifndef zrealloc
#define zrealloc realloc
#endif

#endif /* _ZMALLOC_H */
